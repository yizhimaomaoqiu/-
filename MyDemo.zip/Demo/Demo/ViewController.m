//
//  ViewController.m
//  Demo
//
//  Created by 程国治 on 2017/6/21.
//  Copyright © 2017年 程国治. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
#define SCREEN_WIDTH ([[UIScreen mainScreen]bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen]bounds].size.height)

@interface ViewController ()<WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler>
@property (nonatomic, strong)WKWebView *WKwebView;
@property (nonatomic, strong)NSTimer *timer;
@property (nonatomic, strong)NSArray *components;
@property (nonatomic, strong)NSMutableDictionary *dataDic;
@property (nonatomic, assign)BOOL isCanClick;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.isCanClick = NO;
    
    self.WKwebView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    self.WKwebView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    self.WKwebView.backgroundColor = [UIColor clearColor];
    self.WKwebView.navigationDelegate = self;
    self.WKwebView.UIDelegate = self;
    
    [self.view addSubview:self.WKwebView];
    self.WKwebView.allowsBackForwardNavigationGestures = YES;
    [self.WKwebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://m.baidu.com"]]];
}


//WKWebView代理
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{

}
// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{

    
    ///阻止wkwebview的原生长按弹出
    NSString *js1 = @"document.documentElement.style.webkitUserSelect='none';";
    [self.WKwebView evaluateJavaScript:js1 completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        NSLog(@"response: %@ error: %@", response, error);
        NSLog(@"call js alert by native");
    }];
    NSString *js2 = @"document.documentElement.style.webkitTouchCallout='none';";
    [self.WKwebView evaluateJavaScript:js2 completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        NSLog(@"response: %@ error: %@", response, error);
        NSLog(@"call js alert by native");
    }];
    
}
// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    
    [self zhurujs];
}

//在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    
    WKNavigationActionPolicy actionPolicy = WKNavigationActionPolicyAllow;
    decisionHandler(actionPolicy);
    
    ///如果是跳转新的界面, 就走这个判断
    if (navigationAction.targetFrame == nil) {
        [webView loadRequest:navigationAction.request];
    }
}

- (void)zhurujs{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[self.WKwebView configuration].userContentController addScriptMessageHandler:self name:@"TheData"];
    });
    
    [self injectionJS];
    
}


#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController
      didReceiveScriptMessage:(WKScriptMessage *)message {
    if ([message.name isEqualToString:@"TheData"]) {
        // NSDictionary, and NSNull类型
        //        NSLog(@"~~~~~~~~~~~%@", message.body);
        [self jszhixing:message.body];
    }
}

///js执行代码
- (void)jszhixing:(NSString *)str{
    //    NSLog(@"requestString == %@", str);
    _components = nil;
    _components = [str componentsSeparatedByString:@":"];
    if ([_components count] > 1 && [(NSString *)[_components objectAtIndex:0]
                                   isEqualToString:@"thewebview"]) {
        if([(NSString *)[_components objectAtIndex:1] isEqualToString:@"touch"])
        {
            if ([(NSString *)[_components objectAtIndex:2] isEqualToString:@"start"])
            {
                ///定时器, 判断手势是否长按
                
                _timer = [NSTimer scheduledTimerWithTimeInterval:0.7 target:self selector:@selector(handle) userInfo:nil repeats:NO];
                NSLog(@"start");
            }else if ([(NSString *)[_components objectAtIndex:2] isEqualToString:@"move"]){
                //NSLog(@"这是在滑动");
                if (_timer != nil) {
                    [_timer invalidate];
                    _timer = nil;
                }
                NSLog(@"move");
            }else if ([(NSString*)[_components objectAtIndex:2]isEqualToString:@"cancel"]) {
                if (self.isCanClick == YES) {
                    self.isCanClick = NO;
                    self.WKwebView.scrollView.scrollEnabled = YES;
                }
                if (_timer != nil) {
                    [_timer invalidate];
                    _timer = nil;
                }
                NSLog(@"cancel");
            }else if ([(NSString*)[_components objectAtIndex:2]isEqualToString:@"end"]) {
                if (self.isCanClick == YES) {
                    self.isCanClick = NO;
                    self.WKwebView.scrollView.scrollEnabled = YES;
                }
                if (_timer != nil) {
                    [_timer invalidate];
                    _timer = nil;
                }
                NSLog(@"end");
            }
            
        }
    }
}

- (void)injectionJS{
    
    NSString *js = @"document.ontouchstart=function(event){\
    x=event.targetTouches[0].clientX;\
    y=event.targetTouches[0].clientY;\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:start:\'+x+\':\'+y);\
    };\
    document.ontouchmove=function(event){\
    x=event.targetTouches[0].clientX;\
    y=event.targetTouches[0].clientY;\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:move:\'+x+\':\'+y);\
    };\
    document.ontouchcancel=function(event){\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:cancel');\
    ;};\
    document.ontouchend=function(event){\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:end');\
    };";
    [self.WKwebView evaluateJavaScript:js completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        
    }];
}

- (void)CloseHTMLTouch{
    
    NSString *js = @"document.ontouchstart=function(event){\
    x=event.targetTouches[0].clientX;\
    y=event.targetTouches[0].clientY;\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:start:\'+x+\':\'+y);\
    };\
    document.ontouchmove=function(event){\
    x=event.targetTouches[0].clientX;\
    y=event.targetTouches[0].clientY;\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:move:\'+x+\':\'+y);\
    };\
    document.ontouchcancel=function(event){\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:cancel');\
    ;};\
    document.ontouchend=function(event){\
    event.preventDefault();\
    window.webkit.messageHandlers.TheData.postMessage('thewebview:touch:end');\
    };";
    [self.WKwebView evaluateJavaScript:js completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        
    }];
}


- (void)handle{
    self.isCanClick = YES;
    
    self.WKwebView.scrollView.scrollEnabled = NO;
    ///阻止一次触摸传递
    [self CloseHTMLTouch];
    
    NSLog(@"self.WKwebView.isUserInteractionEnabled == %zd", self.WKwebView.isUserInteractionEnabled);
    
    [_timer invalidate];
    _timer = nil;
    
    if (_components.count == 3) {
        return;
    }
    
    NSLog(@"---------------------------------------");
    
    float ptX = [[_components objectAtIndex:3]floatValue];
    float ptY = [[_components objectAtIndex:4]floatValue];
    NSLog(@"touch point (%f, %f)", ptX, ptY);
    _dataDic = nil;
    _dataDic = [NSMutableDictionary dictionary];
    //第一个js看,是不是广告
    [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).className", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        NSString * className = response;
        if (className != nil && className.length > 0) {
            NSLog(@"className %@", className);
            [_dataDic setValue:className forKey:@"className"];
        }
        //第三个和第四个js看看是不是图片, 要保存
        [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).tagName", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
            NSString * tagName = response;
            NSLog(@"tagName %@", tagName);
            if ([tagName isEqualToString:@"IMG"]) {
                [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).src", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                    NSString * imgURL = response;
                    if (imgURL != nil && imgURL.length > 0) {
                        NSLog(@"imgURL %@", imgURL);
                        [_dataDic setValue:imgURL forKey:@"imgURL"];
                    }
                    
                    [self alertX:ptX Y:ptY];
                }];
            }else{
                if ([tagName isEqualToString:@"DIV"]){
                    ///是DIV, 直接取a
                    [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).getElementsByTagName(\"a\")[0].href", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                        NSString * href = response;
                        if (href != nil && href.length > 0) {
                            NSLog(@"href %@", href);
                            [_dataDic setValue:href forKey:@"href"];
                        }
                        [self alertX:ptX Y:ptY];
                    }];
                }else{
                    [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).parentNode.tagName", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                        if ([response isEqualToString:@"A"]) {
                            [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).parentNode.href", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                                NSString * href = response;
                                if (href != nil && href.length > 0) {
                                    NSLog(@"href %@", href);
                                    [_dataDic setValue:href forKey:@"href"];
                                }
                                [self alertX:ptX Y:ptY];
                            }];
                        }else{
                            [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).parentNode.parentNode.tagName", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                                if ([response isEqualToString:@"A"]) {
                                    [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).parentNode.parentNode.href", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                                        NSString * href = response;
                                        if (href != nil && href.length > 0) {
                                            NSLog(@"href %@", href);
                                            [_dataDic setValue:href forKey:@"href"];
                                        }
                                        [self alertX:ptX Y:ptY];
                                    }];
                                }else{
                                    [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).parentNode.parentNode.parentNode.tagName", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                                        if ([response isEqualToString:@"A"]) {
                                            [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).parentNode.parentNode.parentNode.href", ptX, ptY] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
                                                NSString * href = response;
                                                if (href != nil && href.length > 0) {
                                                    NSLog(@"href %@", href);
                                                    [_dataDic setValue:href forKey:@"href"];
                                                }
                                                [self alertX:ptX Y:ptY];
                                            }];
                                        }else{
                                            [self alertX:ptX Y:ptY];
                                        }
                                    }];
                                }
                            }];
                        }
                    }];
                    
                }
            }
        }];
    }];
}

- (void)alertX:(CGFloat)x Y:(CGFloat)y{
    
    NSString *str = [_dataDic objectForKey:@"href"] != nil ? [_dataDic objectForKey:@"href"] : [_dataDic objectForKey:@"imgURL"] != nil ? [_dataDic objectForKey:@"imgURL"] : nil;
    
    UIAlertController *alC = [UIAlertController alertControllerWithTitle:nil message:str preferredStyle:UIAlertControllerStyleActionSheet];
    [alC addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self injectionJS];
    }]];
    [alC addAction:[UIAlertAction actionWithTitle:@"屏蔽该元素" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self injectionJS];
        [self.WKwebView evaluateJavaScript:[NSString stringWithFormat:@"document.elementFromPoint(%f, %f).style.display = 'none'", x, y] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        }];
    }]];
    if ([_dataDic objectForKey:@"imgURL"]) {
        [alC addAction:[UIAlertAction actionWithTitle:@"下载图片" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            NSData *data = [NSData dataWithContentsOfURL:[NSURL  URLWithString:[_dataDic objectForKey:@"imgURL"]]];
            UIImage *image = [UIImage imageWithData:data]; // 取得图片
            UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
            [self injectionJS];
        }]];
    }
    if ([_dataDic objectForKey:@"href"]) {
        
        [alC addAction:[UIAlertAction actionWithTitle:@"复制链接" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
            pasteboard.string = [_dataDic objectForKey:@"href"];
            [self injectionJS];
        }]];
    }
    
    [self presentViewController:alC animated:YES completion:nil];
}

- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo

{
    
    NSString *msg = nil ;
    
    if(error != NULL){
        msg = @"保存图片失败" ;
    }else{
        msg = @"保存图片成功" ;
    }
    NSLog(@"%@", msg);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
